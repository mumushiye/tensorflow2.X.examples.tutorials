# Deepdream

This example has moved.

[A TensorFlow 2 version is available](https://tensorflow.org/tutorials/generative/deepdream)
[The original is in the TensorFlow examples Repository](https://github.com/tensorflow/examples/tree/master/community/en/r1/deepdream.ipynb)
